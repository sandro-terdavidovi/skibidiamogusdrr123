#product = 1
#if product == 1:
    #print("regular price")
#else:
    #print("discount")

seats = 10
while seats > 0:
    print("sandro")
    seats = seats - 1


i = 0
while i <= 10:
    print(i)
    i = i + 1



number = 0
while number <= 100: 
    print("number")
    number = number + 1
    
age = 18 
if age == 18:
    print("regular price")
else: 
    print("discount")


age = input("enter your age")
if age == 18: 
    print("good luck using our app!")
else:
    print("sorry you cant enter app")