seats = 10
while seats > 0:
    print("sandro")
    seats = seats - 1


i = 0
while i <= 10:
    print(i)
    i = i + 1



number = 0
while number <= 100: 
    print("number")
    number = number + 1