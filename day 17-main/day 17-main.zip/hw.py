age = input("enter your age")
if age == 18:
    print("შენ ხარ სრულწლოვანი")
else:
    print("შენ არხარ სრულწლოვან")


    # if-else გამოიყენება რომ პროგრამამ გამოირჩიოს რა უნდა გააკეთოს თუ პირობა სწორია ერთი რა, თუ არა - მეორე

    # while loop განაგრძობს კოდის შესრულებას, სანამ მის მიერ მოცემული პირობა სწორია (True).

number = 0
while number <= 100: 
    print("number")
    number = number + 1


age = input("enter your age")
if age == 18:
    print("თქვენ გადაიხდით რეგულარული ფასებით")
else:
    print("თქვენ მიიღეთ 20% ფასდაკლება")







